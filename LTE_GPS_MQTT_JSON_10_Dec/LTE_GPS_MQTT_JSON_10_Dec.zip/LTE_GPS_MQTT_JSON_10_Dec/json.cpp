#include <Arduino_JSON.h>
#include "json.h"
#include "user.h"

void create_json_object(char * generated_jeson_sring, String latitude, String longitude)
{
  JSONVar myObject;
  Serial.println("Inside create_json_object function : ");
  
  myObject["id"] = "DEL001";
  myObject["lt"] = latitude;    
  myObject["ln"] = longitude;  
  String jsonString = String(NULL);
  jsonString = JSON.stringify(myObject);
  jsonString.toCharArray(generated_jeson_sring, jsonString.length()+1);
#ifdef dbg
     Serial.print("GPS data in required Jeson string format : ");
     Serial.println(generated_jeson_sring);
#endif
return;
}

bool parse_json_object(const char * received_jeson_string) 
{
  JSONVar myObject = JSON.parse(received_jeson_string);
  // JSON.typeof(jsonVar) can be used to get the type of the var
  if (JSON.typeof(myObject) == "undefined") 
  {
#ifdef dbg
      Serial.println("Parsing input failed!");
#endif
    return 0;
  }

#ifdef dbg
     Serial.print("myObject = ");
     Serial.println(myObject);
#endif
  
  String my_id  = String(NULL);
  String my_lat = String(NULL);
  String my_lon = String(NULL);
  
  if (myObject.hasOwnProperty("id"))
  {
     String my_id = (const char*)myObject["id"];
#ifdef dbg
     Serial.println(my_id);
#endif    
  }
  
  if (myObject.hasOwnProperty("lt"))
  {
  String my_lt = (const char*)myObject["lt"];
#ifdef dbg
     Serial.println(my_lt);
#endif     
  }
   
  if (myObject.hasOwnProperty("ln"))
  {
  String my_ln = (const char*)myObject["ln"];
#ifdef dbg
     Serial.println(my_ln);
#endif     
  }
  return 1;
}
