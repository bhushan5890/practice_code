#include "mqtt.h"
#include "user.h"

char Data[80];    // Generate and Store the sring which is to be send in this char Array 
char Data_HEX[160];
unsigned short DATA_Length;
char packet[250];   // To store generated message packet
char aux_str[250];  // To store generated message packet along with AT command
unsigned long Frame_Length;
char Frame_Length_Hex[10];

unsigned short MQTTProtocolNameLength;
char MQTTProtocolNameLength_Hex[5];
unsigned short MQTTClientIDLength;
char MQTTClientIDLength_Hex[5];
unsigned short MQTTUsernameLength;
char MQTTUsernameLength_Hex[5];
unsigned short MQTTPasswordLength;
char  MQTTPasswordLength_Hex[5];
unsigned short MQTTTopicLength;
char MQTTTopicLength_Hex[5];

const char * MQTTClientID = "ABCDEF";
const char MQTTClientID_Hex[15];
const char * MQTTTopicName = "BNP_TEST";
char MQTTTopicName_Hex[18];
const char * MQTTProtocolName = "MQIsdp";
char MQTTProtocolName_Hex[15];
const char MQTTLVL = 0x03;
char MQTTLVL_Hex[5];
const unsigned short MQTTFlags = 0xC2;
char MQTTFlags_Hex[5];
const unsigned int MQTTKeepAlive = 60;
char MQTTKeepAlive_Hex[5];
const char * MQTTUsername = "naolzyvc";
char MQTTUsername_Hex[17];
const char * MQTTPassword = "zbnrRtkF-xuf";
char MQTTPassword_Hex[25];
const char MQTTPacketID = 0x0001;

unsigned char PUB = 0x30;
char PUB_Hex[5];
unsigned char CONN = 0x10;
char CONN_Hex[5];

// This function genarates the MQTT connect packet and sends it to the MQTT server, to connect with cloud.
bool  MQTTConnect(void) 
{
    bool Connect_packet_Send_Status = false;
    char temp_0 = 0x10;
    memset(packet, 0, sizeof(packet));
    memset(aux_str, 0, sizeof(aux_str));
    MQTTProtocolNameLength = strlen(MQTTProtocolName);  //sprintf stands for “String print”. Instead of printing on console, 
                                                        //it store output on char buffer which are specified in sprintf
    MQTTClientIDLength = strlen(MQTTClientID);
    MQTTUsernameLength = strlen(MQTTUsername);
    MQTTPasswordLength = strlen(MQTTPassword);
    Frame_Length = MQTTProtocolNameLength + 2 + 4 + MQTTClientIDLength + 2 + MQTTUsernameLength + 2 + MQTTPasswordLength + 2;
    hex_number_to_hex_string(CONN,CONN_Hex,1);
    hex_number_to_hex_string(Frame_Length,Frame_Length_Hex,1);
    str_to_hex_Str(MQTTProtocolName,MQTTProtocolName_Hex);
    str_to_hex_Str(MQTTClientID,MQTTClientID_Hex);
    str_to_hex_Str(MQTTUsername,MQTTUsername_Hex);
    str_to_hex_Str(MQTTPassword,MQTTPassword_Hex);
    hex_number_to_hex_string(MQTTProtocolNameLength,MQTTProtocolNameLength_Hex,2);
    hex_number_to_hex_string(MQTTKeepAlive,MQTTKeepAlive_Hex,2);
    hex_number_to_hex_string(MQTTClientIDLength,MQTTClientIDLength_Hex,2);
    hex_number_to_hex_string(MQTTUsernameLength,MQTTUsernameLength_Hex,2);
    hex_number_to_hex_string(MQTTPasswordLength,MQTTPasswordLength_Hex,2); 
    hex_number_to_hex_string(MQTTLVL,MQTTLVL_Hex,1);
    hex_number_to_hex_string(MQTTFlags,MQTTFlags_Hex,1);
        
    snprintf(packet, sizeof(packet), "\"%s%s%s%s%s%s%s%s%s%s%s%s%s\"",CONN_Hex,Frame_Length_Hex,MQTTProtocolNameLength_Hex,MQTTProtocolName_Hex,MQTTLVL_Hex,MQTTFlags_Hex,MQTTKeepAlive_Hex,MQTTClientIDLength_Hex,MQTTClientID_Hex,MQTTUsernameLength_Hex,MQTTUsername_Hex,MQTTPasswordLength_Hex,MQTTPassword_Hex); 
 
    snprintf(aux_str, sizeof(aux_str), "AT+QISENDEX=0,%s",packet);
#ifdef dbg
    Serial.println("Sending connect packet"); 
#endif
  Connect_packet_Send_Status = sendATcommand(aux_str, "SEND OK", 10000);
  if(Connect_packet_Send_Status == true)
  {
#ifdef dbg
     Serial.println("connect packet sent"); 
#endif
     delay(1000);
     serial2_Flush();
  }   
  else
  {
#ifdef dbg
     Serial.println("Failed to Send Connection Packet");
#endif   
     Disconnect_TCP_Connection(); 
  }
  return Connect_packet_Send_Status;    // 1- Packet send successfully, 0- Failed to send the packet

/*
  Serial.println("Sending connect packet");
  sendATcommand("AT+QISENDEX=0,\"102C00064D514973647003C2003C000641424344454600086E616F6C7A797663000C7A626E7252746B462D787566\"", "SEND OK", 2000);
  delay(1000);
  serial2_Flush();
  Serial.println("connect packet sent");
  return false;
  */
}

// This function genarates the MQTT publish packet and sends it to the MQTT server, to publish data to the cloud.
bool  MQTTpublish(char * Data) 
{
    char Data_Hex[strlen(Data)];
    bool Publish_packet_Send_Status = false;
    memset(packet, 0, sizeof(packet));
    memset(aux_str, 0, sizeof(aux_str));
    hex_number_to_hex_string(PUB,PUB_Hex,1);
    MQTTTopicLength = strlen(MQTTTopicName);
    hex_number_to_hex_string(MQTTTopicLength,MQTTTopicLength_Hex,2);
    DATA_Length = strlen(Data);
    str_to_hex_Str(Data,Data_HEX);
    Frame_Length = 2 + MQTTTopicLength + DATA_Length;
    hex_number_to_hex_string(Frame_Length,Frame_Length_Hex,1);
    str_to_hex_Str(MQTTTopicName,MQTTTopicName_Hex);
    snprintf(packet, sizeof(packet), "\"%s%s%s%s%s\"",PUB_Hex,Frame_Length_Hex,MQTTTopicLength_Hex,MQTTTopicName_Hex,Data_HEX);
    snprintf(aux_str, sizeof(aux_str), "AT+QISENDEX=0,%s",packet);
#ifdef dbg
    Serial.println("Sending publish packet");
#endif     
    Publish_packet_Send_Status = sendATcommand(aux_str, "SEND OK", 10000);
    if(Publish_packet_Send_Status == true)
    {
#ifdef dbg
       Serial.println("Publish packet sent"); 
#endif 
       delay(1000);
       serial2_Flush();
       Publish_packet_Send_Status = 1;
    }   
    else
    {
#ifdef dbg
        Serial.println("Failed to Send Publish Packet");
        Publish_packet_Send_Status = 0;
        InitModule_publish_to_MQTT_server(Data);    //Initialize module, TCP connection, reconnect to MQQTT server and retry to publish the data
#endif
    }
    return Publish_packet_Send_Status;      // 1- Packet published successfully, 0- Failed to publish packet
  /*  
  delay(5000); 
  Serial.println("Sending Publish packet");
//  Serial2.println("AT+QISENDEX=0,\"30130008424E505F5445535448695361727468616B\"");
  sendATcommand("AT+QISENDEX=0,\"30130008424E505F5445535448695361727468616B\"", "SEND OK", 2000);
  Serial.println("Publish packet sent");
*/
}

/***************************************************************************************************************************/
// MQTTsubscribe is yet to be implemented, following functions are required to be edited to make following code working
/***************************************************************************************************************************/
/*
// Following Global Variables are used in the following code, Uncomment them if necessary
//char sim800lreset = 4;
//const char MQTTQOS = 0x00;
//const char * MQTTTopic2 = "Bhushan";
//unsigned char encodedByte;
//int X;
//unsigned long checksum, rLength;
//unsigned short topiclength;
//unsigned short topiclength2;
//unsigned char topic[30];

void MQTTsubscribe() {

  if (sendATcommand2("AT+CIPSEND", ">", "ERROR", 1000)) {

    memset(str, 0, 250);
    topiclength2 = strlen(MQTTTopic2);
    Frame_Length = 2 + 2 + topiclength2 + 1;
    delay(1000);

    Serial2.write(0x82);
    X = Frame_Length;
    do
    {
      encodedByte = X % 128;
      X = X / 128;
      // if there are more data to encode, set the top bit of this byte
      if ( X > 0 ) {
        encodedByte |= 128;
      }
      Serial2.write(encodedByte);
    }
    while ( X > 0 );
    Serial2.write(MQTTPacketID >> 8);
    Serial2.write(MQTTPacketID & 0xFF);
    Serial2.write(topiclength2 >> 8);
    Serial2.write(topiclength2 & 0xFF);
    Serial2.print(MQTTTopic2);
    Serial2.write(MQTTQOS);

    Serial2.write(0x1A);
    if (sendATcommand2("", "SEND OK", "SEND FAIL", 5000)) {
      Serial.println(F("SUBSCRIBE PACKET SENT"));
      return 1;
    }
    else return 0;
  }

}


int8_t readServerResponse(char* ATcommand, char* expected_answer1, char* expected_answer2, unsigned int timeout) {
  unsigned long nowMillis = millis();
  Serial2.println(ATcommand);
  delay(3000);
 
  if (Serial2.available()) {
    while (char(Serial.read()) != 0x24) {
      if ((millis() - nowMillis) > 2000) {
        Serial.println("NO DATA RECEIVED FROM REMOTE");
        break;
      }
    }
    nowMillis=(millis());
    while (Serial2.available()) {
      Serial.print(char(Serial2.read()));
    }
  }

}

*/
