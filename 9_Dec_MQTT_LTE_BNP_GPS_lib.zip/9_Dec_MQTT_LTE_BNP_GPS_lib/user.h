#include "gps.h"
#include <Arduino.h>

#define dbg     // Disply debug messages on serial terminal
#define GPS_BAUD 115200

//# define DEVICE_ID 1

/*!
 * @struct      device_info
 * @brief       Device specific info.
 */
struct device_info
{
  String device_id = "1";//DEVICE_ID;      /*!< Unique device ID. */ 
};

/*!
 * @ struct gps_data
 * @brief Contains the GPS info
 */
struct gps_data
{
  String g_time;    /*!<GPS time*/
  String g_date;    /*!<GPS date*/
  String g_lon;     /*!<GPS longitude*/
  String g_lat;     /*!<GPS latitude*/
  String g_err;    /*!<GPS error*/
  //String g_speed;   /*!<GPS speed*/
};

/*!
 * @ enum gps_err
 * @brief Contains error info related to GPS
 */
enum gps_err
{
  VALID_GPS_DATA=0,   /*!<Valid GPS data*/
  INVALID_GPS_DATA=1, /*!<Invalid GPS data*/
  GPS_FAILED=2        /*!<GPS failed check wiring*/
};

bool Collect_GPS_DATA(void);
int8_t Send_GPS_AT_Command(void);
void get_gps_data(char * GPS_data_string);
void init_gps_dataTo_null(void);
/******************From main fiile ***************/
//bool  MQTTConnect(void);
//int8_t sendATcommand2(char* ATcommand, char* expected_answer1, char* expected_answer2, unsigned int timeout);
