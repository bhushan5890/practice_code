#include "user.h"
//#include "gps.h"
extern char NMEA_STRING[100];
extern int8_t sendATcommand2(char* ATcommand, char* expected_answer1, char* expected_answer2, unsigned int timeout);
extern bool  MQTTpublish(char * Data);

char Publish_GPS_data[50];
unsigned long tx_start = 0;

unsigned long data_update_interval =  60000;//1min

bool GPS_Init = true;

bool valid_gps_data = false;
/*!
 * @var gps
 * @brief Contains GPS info 
 */
GPSData gps;

/*!
 * @var gps_failed
 * @brief It is true if there is any GPS wiring problem
 */
bool gps_failed = false;

/*!
 * @var read_gps_data
 * @brief It is true if get valid GPS data 
 */
bool read_gps_data=false;

/*!
 * @struct gps_info
 * @brief Contains GPS related info
 */
struct gps_data gps_info;

/*!
 * @fn      void get_gps_data()
 * @brief   To read GPS data and assigning data to GPS Structure
 */
void get_gps_data(char * GPS_data_string)
{
  int string_len_LAT=0,string_len_LON=0;
  char char_array_LAT[12];
  char char_array_LON[12];
  init_gps_dataTo_null();
  memset(Publish_GPS_data, '\0', sizeof(Publish_GPS_data));
  memset(char_array_LAT,'\0', sizeof(char_array_LAT));
  memset(char_array_LON, '\0', sizeof(char_array_LON));
  
  for(;*GPS_data_string != '\0';GPS_data_string++)
  {
    if(gps.encode(*GPS_data_string))
    {
            read_gps_data=true;
            if ((gps.location.isValid()) && (gps.date.isValid()) && (gps.time.isValid()))
            {
              gps_failed = false; 
              valid_gps_data = true;
              uint8_t time_h = gps.time.hour() + 5;
              if (time_h > 23)
                time_h = time_h - 24;
            
              uint8_t time_m = gps.time.minute() + 30;
              if (time_m > 59)
              {
                time_m = time_m - 60;
                time_h = time_h + 1;
              }
              gps_info.g_time      = String(time_h) + ":" + String(time_m) + ":" + String(gps.time.second());
              gps_info.g_date      = String(gps.date.day()) + "-" + String(gps.date.month()) + "-" + String(gps.date.year());
              gps_info.g_lon       = String(gps.location.lng(), 6);
              gps_info.g_lat       = String(gps.location.lat(), 6);
              gps_info.g_err       = String(VALID_GPS_DATA);
              //gps_info.g_speed     = String(gps.speed.kmph());
            }
            else
            {
              valid_gps_data = false;
              if (gps_failed)
              {
                gps_info.g_err     = String(GPS_FAILED);
              }
              else
              {
                gps_info.g_err     = String(INVALID_GPS_DATA);
              }
            
            }         
        }
        if (millis() > 10000 && gps.charsProcessed() < 10)
        {
          Serial.println(F("\n\n[ERR]\tNo GPS detected: check wiring."));
          gps_failed = true;
          delay(2000);
        }
   }
   string_len_LAT = gps_info.g_lat.length();
   string_len_LON = gps_info.g_lon.length();
   //if((gps_info.g_lat.length() < 9) || (gps_info.g_lon.length() < 9))
   if((string_len_LAT < 9) || (string_len_LON < 9))
   {
        Serial.println("GNSS Engine is still activating");
   }
   else
   {
    Serial.println("Sending Lat , Long information to MQTT Server");
    gps_info.g_lat.toCharArray(char_array_LAT, string_len_LAT+1);
    gps_info.g_lon.toCharArray(char_array_LON, string_len_LON+1);
    //char * bnp = Publish_GPS_data;
    snprintf(Publish_GPS_data, sizeof(Publish_GPS_data), "Lat:%s,Lon:%s",char_array_LAT,char_array_LON);
    Serial.println(Publish_GPS_data);
    //MQTTpublish(bnp);
    //MQTTpublish(char * Publish_GPS_data);
//       Serial.print("Lattitude : ");
//       Serial.println(gps_info.g_lat);
//       Serial.print("Longitude : ");
//       Serial.println(gps_info.g_lon);         
   }
}

/*!
 * @fn      void init_gps_dataTo_null()
 * @brief   Initialize the GPS data to NULL
 */
void init_gps_dataTo_null(void)
{
   gps_info.g_time      = String(NULL);
   gps_info.g_date      = String(NULL);
   gps_info.g_lon       = String(NULL);
   gps_info.g_lat       = String(NULL);
   gps_info.g_err       = String(NULL);
}

bool Collect_GPS_DATA(void)
{
   char gps_status= 0;
   memset(NMEA_STRING, '\0', sizeof(NMEA_STRING));
   gps_status = sendATcommand2("AT+QGPS?", "+QGPS: 1", "+QGPS: 0", 2000);
   Serial2.flush();
 if(gps_status == 1)
 { 
   delay(10);
   Send_GPS_AT_Command();
   //Parse_NMEA_RMC_String();
#ifdef dbg
    Serial.println("GPS info.collected : ");  
#endif
 }
 else if(gps_status == 2)
 {
   if(sendATcommand2("AT+QGPS = 1", "OK", "+CME ERROR: Session is ongoing", 2000))
   {
    delay(10);
    Send_GPS_AT_Command(); 
    //Parse_NMEA_RMC_String();
#ifdef dbg
    Serial.println("GPS info.collected : ");  
#endif
   }
 }
}

int8_t Send_GPS_AT_Command(void) 
{
  uint8_t x = 0,  answer = 0;
  unsigned long previous=0;
  Serial2.println("AT+QGPSGNMEA=\"RMC\"");    // Send the AT command
  previous = millis();  
  //do // this loop waits for the answer
  //while (((millis() - previous) < 500))
  while (((millis() - previous) < 500))
  {
    if (Serial2.available() != 0)// if there are data in the UART input buffer, reads it and checks for the asnwer
    {
       NMEA_STRING[x] = Serial2.read();
      (NMEA_STRING[x] == ' ') ? x=0:x++;      // Save the received string "+QGPSGNMEA: " onwords
    }
  } 
  get_gps_data(NMEA_STRING);
#ifdef dbg
     Serial.print("Received NMEA_RMC_STRING : ");
     Serial.println(NMEA_STRING);
#endif
}
