#define __MQTTClientID         "ABCDEF"
#define __MQTTTopicName        "BNP_TEST"
#define __MQTTProtocolName     "MQIsdp"
#define __MQTTUsername         "naolzyvc"
#define __MQTTPassword         "zbnrRtkF-xuf"
#define __MQTTLVL       0x03
#define __MQTTFlags     0xC2
#define __MQTTKeepAlive 60
#define __PUB           0x30
#define __CONN          0x10

//const char * MQTTClientID = "ABCDEF";
//const char * MQTTTopicName = "BNP_TEST";
//const char * MQTTProtocolName = "MQIsdp";
//const char * MQTTUsername = "naolzyvc";
//const char * MQTTPassword = "zbnrRtkF-xuf";
//const char MQTTLVL = 0x03;
//const unsigned short MQTTFlags = 0xC2;
//const unsigned int MQTTKeepAlive = 60;
//const char MQTTPacketID = 0x0001;
//unsigned char PUB = 0x30;
//unsigned char CONN = 0x10;

bool  MQTTConnect(void);
bool  MQTTpublish(char * Data);
