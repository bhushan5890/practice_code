#include <Arduino.h>
#include "gps.h"
#include "json.h"
#include "mqtt.h"
#include "init_module.h"

#define dbg     // Disply debug messages on serial terminal
#define GPS_BAUD 115200


# define DEVICE_ID "DEL001"

/*!
 * @struct      device_info
 * @brief       Device specific info.
 */
struct device_info
{
  String device_id = "1";//DEVICE_ID;      /*!< Unique device ID. */ 
};

/*!
 * @ struct gps_data
 * @brief Contains the GPS info
 */
struct gps_data
{
  String g_time;    /*!<GPS time*/
  String g_date;    /*!<GPS date*/
  String g_lon;     /*!<GPS longitude*/
  String g_lat;     /*!<GPS latitude*/
  String g_err;    /*!<GPS error*/
  //String g_speed;   /*!<GPS speed*/
};

/*!
 * @ enum gps_err
 * @brief Contains error info related to GPS
 */
enum gps_err
{
  VALID_GPS_DATA=0,   /*!<Valid GPS data*/
  INVALID_GPS_DATA=1, /*!<Invalid GPS data*/
  GPS_FAILED=2        /*!<GPS failed check wiring*/
};


void Parse_GPS_NMEA_RMC_String(char * GPS_data_string);
void init_gps_dataTo_null(void);
bool Collect_GPS_DATA(void);
int8_t Send_GPS_AT_Command(void);
int8_t sendATcommand(char* ATcommand, char* expected_answer, unsigned int timeout);
int8_t sendATcommand2(char* ATcommand, char* expected_answer1, char* expected_answer2, unsigned int timeout);
void ShowSerialData(void);
void serial2_Flush(void);
void str_to_hex_Str(char* input, char* output);
void hex_number_to_hex_string(unsigned short input_hex, char * output_string,unsigned char No_of_Byte_output);
/******************From main fiile ***************/
//bool  MQTTConnect(void);
//int8_t sendATcommand2(char* ATcommand, char* expected_answer1, char* expected_answer2, unsigned int timeout);
