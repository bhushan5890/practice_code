#include "user.h"

//extern bool InitModule_publish_to_MQTT_server(const char * Data_to_be_published);
//extern int8_t sendATcommand2(char* ATcommand, char* expected_answer1, char* expected_answer2, unsigned int timeout);
//extern bool  MQTTpublish(char * Data);

char Publish_GPS_jsondata[50];
unsigned long tx_start = 0;

unsigned long data_update_interval =  60000;//1min

bool GPS_Init = true;

bool valid_gps_data = false;
/*!
 * @var gps
 * @brief Contains GPS info 
 */
GPSData gps;

/*!
 * @var gps_failed
 * @brief It is true if there is any GPS wiring problem
 */
bool gps_failed = false;

/*
 * @var read_gps_data
 * @brief It is true if get valid GPS data 
 */
bool read_gps_data=false;

/*!
 * @struct gps_info
 * @brief Contains GPS related info
 */
struct gps_data gps_info;

/*!
 * @fn      void Parse_GPS_NMEA_RMC_String()
 * @brief   To read GPS data and assigning data to GPS Structure
 */
void Parse_GPS_NMEA_RMC_String(char * GPS_data_string)
{
  int string_len_LAT=0,string_len_LON=0;
  char json_output_string[50];
  init_gps_dataTo_null();
  memset(json_output_string, '\0', sizeof(json_output_string));
  memset(Publish_GPS_jsondata, '\0', sizeof(Publish_GPS_jsondata));
  
  for(;*GPS_data_string != '\0';GPS_data_string++)
  {
    if(gps.encode(*GPS_data_string))
    {
            read_gps_data=true;
            if ((gps.location.isValid()) && (gps.date.isValid()) && (gps.time.isValid()))
            {
              gps_failed = false; 
              valid_gps_data = true;
              uint8_t time_h = gps.time.hour() + 5;
              if (time_h > 23)
                time_h = time_h - 24;
            
              uint8_t time_m = gps.time.minute() + 30;
              if (time_m > 59)
              {
                time_m = time_m - 60;
                time_h = time_h + 1;
              }
              gps_info.g_time      = String(time_h) + ":" + String(time_m) + ":" + String(gps.time.second());
              gps_info.g_date      = String(gps.date.day()) + "-" + String(gps.date.month()) + "-" + String(gps.date.year());
              gps_info.g_lon       = String(gps.location.lng(), 6);
              gps_info.g_lat       = String(gps.location.lat(), 6);
              gps_info.g_err       = String(VALID_GPS_DATA);
              //gps_info.g_speed     = String(gps.speed.kmph());
            }
            else
            {
              valid_gps_data = false;
              if (gps_failed)
              {
                gps_info.g_err     = String(GPS_FAILED);
              }
              else
              {
                gps_info.g_err     = String(INVALID_GPS_DATA);
              }
            }         
        }
        if (millis() > 10000 && gps.charsProcessed() < 10)
        {
          Serial.println(F("\n\n[ERR]\tNo GPS detected: check wiring."));
          gps_failed = true;
          //delay(2000);
        }
   }
   string_len_LAT = gps_info.g_lat.length();
   string_len_LON = gps_info.g_lon.length();
   if((string_len_LAT < 9) || (string_len_LON < 9))
   {
#ifdef dbg
     Serial.print("Invalid GPS Data Received, NMEA_RMC_STRING : ");
     Serial.println("GNSS Engine is not yet activated completely, Could not read valid GPS data");
#endif        
   }
   else
   {
    create_json_object(Publish_GPS_jsondata,gps_info.g_lat,gps_info.g_lon);   
    MQTTpublish(Publish_GPS_jsondata);         
   }
}

/*!
 * @fn      void init_gps_dataTo_null()
 * @brief   Initialize the GPS data to NULL
 */
void init_gps_dataTo_null(void)
{
   gps_info.g_time      = String(NULL);
   gps_info.g_date      = String(NULL);
   gps_info.g_lon       = String(NULL);
   gps_info.g_lat       = String(NULL);
   gps_info.g_err       = String(NULL);
}

bool Collect_GPS_DATA(void)
{
   char gps_status= 0;
   gps_status = sendATcommand2("AT+QGPS?", "+QGPS: 1", "+QGPS: 0", 2000);
   Serial2.flush();
 if(gps_status == 1)
 { 
   delay(10);
   Send_GPS_AT_Command();
 }
 else if(gps_status == 2)
 {
   if(sendATcommand2("AT+QGPS = 1", "OK", "+CME ERROR: Session is ongoing", 2000))
   {
    delay(10);
    Send_GPS_AT_Command(); 
   }
 }
}

int8_t Send_GPS_AT_Command(void) 
{
  char NMEA_STRING[100];
  uint8_t x = 0,  answer = 0;
  unsigned long previous=0;
  memset(NMEA_STRING, '\0', sizeof(NMEA_STRING));
  Serial2.println("AT+QGPSGNMEA=\"RMC\"");    // Send the AT command
  previous = millis();  
  while (((millis() - previous) < 500))
  {
    if (Serial2.available() != 0)// if there are data in the UART input buffer, reads it and checks for the asnwer
    {
       NMEA_STRING[x] = Serial2.read();
      (NMEA_STRING[x] == ' ') ? x=0:x++;      // Save the received string "+QGPSGNMEA: " onwords
    }
  }
#ifdef dbg
     Serial.print("GPS data collected, Received NMEA_RMC_STRING : ");
     Serial.println(NMEA_STRING);
#endif
  Parse_GPS_NMEA_RMC_String(NMEA_STRING);
}

// Sends the ATcommand and compares the response with expected_answer.
// Continues the operation till gets success otherwise timeout period over, if failed terminates the operation with Error message.
int8_t sendATcommand(char* ATcommand, char* expected_answer, unsigned int timeout) 
{
  uint8_t x = 0,  answer = 0;
  char response[500];
  unsigned long previous;
  char* str;
  uint8_t index = 0;

  memset(response, '\0', 100);    // Initialize the string

  delay(100);

  while ( Serial2.available() > 0) Serial2.read();   // Clean the input buffer

  Serial2.println(ATcommand);    // Send the AT command
#ifdef dbg
  Serial.println(ATcommand);    // Send the AT command
#endif
  x = 0;
  previous = millis();

  // this loop waits for the answer
  do {
    if (Serial2.available() != 0) {
      // if there are data in the UART input buffer, reads it and checks for the asnwer
      response[x] = Serial2.read();
      //Serial2.print(response[x]);
      x++;
      // check if the desired answer  is in the response of the module
      if (strstr(response, expected_answer) != NULL)
      {
        answer = 1;
      }
    }
  }
  // Waits for the asnwer with time out
  while ((answer == 0) && ((millis() - previous) < timeout));

#ifdef dbg
  Serial.println(response);    // Send the AT command
#endif
  return answer;
}

// Sends the ATcommand and compares the response with expected_answer1 and expected_answer2.
// Continues the operation till gets success otherwise timeout period over, if failed terminates the operation with Error message.
int8_t sendATcommand2(char* ATcommand, char* expected_answer1, char* expected_answer2, unsigned int timeout) 
{
  uint8_t x = 0,  answer = 0;
  char response[100];
  unsigned long previous;

  memset(response, '\0', 100);    // Initialize the string

  delay(100);

  Serial2.flush();
  Serial2.println(ATcommand);    // Send the AT command
  //if(strstr(ATcommand, "AT+CIPSEND")!=NULL) Serial2.write(0x1A);

#ifdef dbg
  Serial.println(ATcommand);    // Send the AT command
#endif

  x = 0;
  previous = millis();

  // this loop waits for the answer
  do {
    // if there are data in the UART input buffer, reads it and checks for the asnwer
    if (Serial2.available() != 0) {
      response[x] = Serial2.read();
      x++;
      // check if the desired answer 1  is in the response of the module
      if (strstr(response, expected_answer1) != NULL)
      {
        answer = 1;
        while (Serial.available()) {
          response[x] = Serial2.read();
          x++;
        }
      }
      // check if the desired answer 2 is in the response of the module
      else if (strstr(response, expected_answer2) != NULL)
      {
        answer = 2;
        while (Serial.available()) {
          response[x] = Serial2.read();
          x++;
        }
      }

    }
  }
  // Waits for the asnwer with time out
  while ((answer == 0) && ((millis() - previous) < timeout));
#ifdef dbg
  Serial.println(response);
#endif
  return answer;
}


// Shows the response from LTE module read from serial2 to serial monitor.
void ShowSerialData(void)
{
//#ifdef dbg
  while(Serial2.available()!=0)  // If data is available on serial port
  Serial.write(char (Serial2.read())); // Print character received on to the serial monitor
//#endif
}

// Read the data available on serial port2 and make the buffer empty
void serial2_Flush(void)    //Read the data available on serial port2 and make the buffer empty
{
  char t;
  while(Serial2.available() != 0) 
  {
    t = Serial2.read();
  }
}

// Accepts the address of the prdefined string and converts it to equivalent Hex string, which can be access from output
void str_to_hex_Str(char* input, char* output)    // Function to convert given String to equivalent Hex string
{
    int loop=0;
    int i=0; 
    while(input[loop] != '\0')
    {
        sprintf((char*)(output+i),"%02X", input[loop]);
        loop+=1;
        i+=2;
    }
    output[i++] = '\0';    //insert NULL at the end of the output string
    return;
}

// Function converts assigned number to Hex string e.g. 0xC2 to "00C2" if No_of_Byte_output=2, otherwise to "C2" if No_of_Byte_output=1
void hex_number_to_hex_string(unsigned short input_hex, char * output_string,unsigned char No_of_Byte_output) // Function converts assigned number to Hex string e.g. 0xC2 to "C2" 
{
  if(No_of_Byte_output == 2)
  {
      if(input_hex > 0xFFF)
      {
       sprintf(output_string,"%X",input_hex);   // e.g. 0x3A2F converted to "3A2F"
      }
      else if(input_hex > 0xFF)
      {
       sprintf(output_string,"0%X",input_hex);  // e.g. 0xA2F converted to "0A2F"    
      }
      else if(input_hex > 0xF)
      {
       sprintf(output_string,"00%X",input_hex); // e.g. 0x2F converted to "002F"      
      }
      else
      {
        sprintf(output_string,"000%X",input_hex); // e.g. 0xF converted to "000F"      
      }
   }
   else if(No_of_Byte_output == 1)
   {
       if(input_hex <= 0xF)
       sprintf(output_string,"0%X",input_hex);// e.g. 0xF converted to "0F"
       else if(input_hex <= 0xFF)
       sprintf(output_string,"%X",input_hex);// e.g. 0xCF converted to "CF"
   } 
}
