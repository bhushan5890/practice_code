#include "init_module.h"
#include "user.h"

/*
const char * __APN      = "airtelgprs.com";     // Sim card specific, this is written for AIRTEL sim card
const char * __usrnm    = "";                   // If present
const char * __password = "";                   // If present
const char * MQTTHost = "farmer.cloudmqtt.com";   //We even replace it with server IP address : "34.250.16.30";
const int    MQTTPort = 12575;
*/
bool InitModule_publish_to_MQTT_server(const char * Data_to_be_published)
{ 
  bool return_status = false;
  Disconnect_TCP_Connection();
  if(Initialize_module() == true)
  {
    if(initTCP() == true)
    {        
      if(MQTTConnect() == true)
      {
         return_status = MQTTpublish(Data_to_be_published);
         Serial.println("Welcome message");
      }              
    }
  }
  return return_status; 
}

// This function checks module is active or not, success if Module responds to the command AT with "OK" other wise Failure.
bool reset_LTE_Module(void) 
{
  uint8_t answer = 0;
  answer = sendATcommand("AT", "OK", 2000);     // checks if the module is started
  if (answer == 1)
  sendATcommand("ATE0", "OK", 1000);// Set Command Echo mode, ATE<value>: 0-Echo mode OFF, 1-Echo mode ON                                 
  else if (answer == 0)
  {
    // waits for an answer from the module
    int trials = 0;
    while (answer == 0) 
    {
      trials++;
      // Send AT every two seconds and wait for the answer
      answer = sendATcommand("AT", "OK", 100);
      if ((trials == 10)&&(answer == 0))
      {
#ifdef dbg
        Serial.println(F("LTE module Failed to  Start"));
#endif
        return false;       // return 0, LTE module Failed to  Start 
      }
    }
  }
  if (answer == 1)
  {
#ifdef dbg
      Serial.println(F("LTE module Started successfully"));        
#endif
      return true;              // return 1, LTE module Started successfully 
  }
}

//If module initialized successfully, it initiates the TCP connection with the server using AT commands, and credentials of the server.
bool initTCP(void) 
{
   char str_apn_user_psw[80];
   memset(str_apn_user_psw, '\0', sizeof(str_apn_user_psw));
#ifdef dbg
      Serial.println(F("Initializing TCP connection"));
#endif
       // snprintf() formats and stores a series of characters and values in the array buffer aux_str
      snprintf(str_apn_user_psw, sizeof(str_apn_user_psw), "AT+QICSGP=1,1,\"%s\",\"%s\",\"%s\",0", __APN, __usrnm, __password);  // Sets the APN, user name and password
       //Format: AT+QICSGP=<contextid>,<context type>,[<apn>[,<username>,<password>)[,<authentication>]]]
      if (sendATcommand(str_apn_user_psw, "OK", 3000) == 1)
      {
          delay(10);
        // Waits for status IP START
       //Format:AT+QIACT=<contextid>
        if (sendATcommand("AT+QIACT=1", "OK", 2000)  == 1 )   //Activate GPRS context profile, context 1
          {
            delay(10);
#ifdef dbg
            Serial.println(F("Opening TCP"));
#endif
            memset(str_apn_user_psw, '\0', sizeof(str_apn_user_psw));
            snprintf(str_apn_user_psw, sizeof(str_apn_user_psw), "AT+QIOPEN=1,0,\"TCP\",\"%s\",%d,0,1", MQTTHost,MQTTPort); //connect to a TCP server-MQTTHost, port-MQTTPort
            //Format: AT+QIOPEN=<contextid>,<connectid>,<servicetype>,<ipaddress/domainname>,<remoteport>[,<localport>,<accessmode>]

            // Opens a TCP socket
            if (sendATcommand(str_apn_user_psw, "OK", 15000) == 1)
            {
#ifdef dbg
              Serial.println(F("Connection has Eshtablished with MQTT server successfully"));
#endif
              delay(1000);          // Dont minimize this delay, must be at least 1000 ms
              serial2_Flush();
#ifdef dbg
              Serial.println("TCP Initialization completed");
#endif
              return true;  // return 1, TCP Initialization completed
            }
            else
            {
#ifdef dbg
              Serial.println(F("Error opening the connection"));
              Serial.println(F("UNABLE TO CONNECT TO SERVER, initTCP failed "));
#endif
              return false;   // return 0, connection failed
            }
          }
      }
}

//It Initializes the module, terminates the operation if some ambiguity is reported while intialization with error message to serial terminal.
bool Initialize_module(void)        //Initialize the LTE module
{
    bool Indicator = false;
    char iteration = 0;
#ifdef dbg     
    Serial.println("Initializing Module");
#endif
    for(iteration = 0; iteration <=7 ; iteration++)
    {
          switch(iteration)
          {
              case 0:Indicator = reset_LTE_Module();
                     delay(10);
                     break;
              case 1:Indicator = sendATcommand2("AT+IPR?","+IPR: 115200","OK",2000);    //verification of Baud Rate value
                     delay(10);
                     break;
              case 2:Indicator = sendATcommand("ATV1","OK",2000);   // set the response format, When <value>=0:0 When <value>=1:OK
                     delay(10);
                     break;
              case 3:Indicator = sendATcommand("AT+CMEE=2","OK",2000); /* Error Message Format AT+CMEE=<n> 
                                                      0 Disable result code
                                                      1 Enable result code and use numeric values
                                                      2 Enable result code and use verbose values */
                     delay(10);
                     break;                           
              case 4:Indicator = sendATcommand("AT+QURCCFG=\"URCPORT\",\"uart1\"","OK",2000); // Configure URC Indication Option 
                     delay(10);
                     break;
              case 5:Indicator = sendATcommand2("AT+CPIN?","+CPIN: READY","OK",2000); //SIM card status : SIM card inserted or not, locked or unlocked
                     if (Indicator == false)
                     Serial.println("SIM card not detected, other wise locked");
                     delay(10);
                     break;
              case 6:Indicator = sendATcommand2("AT+CREG?","+CREG: 0,1","OK",2000); // Query the GSM network register status, +CREG: 0,1 is registered successfully. 
                     delay(10);
                     break;
              case 7:Indicator = sendATcommand2("AT+CGREG?","+CGREG: 0,1","OK",2000); // Query the GPRS network register status, +CGREG: 0,1 is registered successfully.
                     delay(10);
                     serial2_Flush();
                     
                     break;
              default:;
          }
          if(Indicator == false)
          {
#ifdef dbg         
            Serial.println("Module Initialization failed");
#endif
            return false;   // return 0, Module Initialization failed
          } 
    }
#ifdef dbg
            Serial.println("Module initialized successfully");
#endif
    return true;            // return 1, Module initialized successfully
}

//It Disconnects the connections and deactivates the PDP context, to end previously build connections.
bool Disconnect_TCP_Connection(void)
{
#ifdef dbg
   Serial.println("Disconnecting TCP Connection");
#endif
  sendATcommand("ATE0", "OK", 1000);  // Set Command Echo mode, ATE<value>: 0-Echo mode OFF, 1-Echo mode ON
  if(sendATcommand("AT+QICLOSE=0", "OK", 1000))     // Close the connection of TCP/UDP, AT+QICLOSE=<connectid>
  {
    if(sendATcommand("AT+QIDEACT=1", "OK", 1000))   // Deactivate GPRS context, AT+QIACT=<contextid>
    {
#ifdef dbg
      Serial.println("PDP Deactivated successfully");
#endif
      return true;      
    }
  }
  else
  {
#ifdef dbg
    Serial.println("TCP/UDP connection not Closed");
#endif
     return false;
  }
  return false;
}
