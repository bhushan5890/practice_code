#define __APN "airtelgprs.com"          // Sim card specific, this is written for AIRTEL sim card
#define __usrnm  ""                     // If present
#define __password  ""                  // If present
#define MQTTHost "farmer.cloudmqtt.com" //We even replace it with server IP address : "34.250.16.30";
#define MQTTPort 12575

bool InitModule_publish_to_MQTT_server(const char * Data_to_be_published);
bool reset_LTE_Module(void);
bool initTCP(void);
bool Initialize_module(void);
bool Disconnect_TCP_Connection(void);
